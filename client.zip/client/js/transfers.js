const transferForm = document.getElementById("transferForm")

transferForm.addEventListener("submit", function(e){

e.preventDefault()

alert("Transfer Completed. Location Updated!")

})
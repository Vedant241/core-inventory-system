// Temporary demo data

document.getElementById("totalProducts").innerText = 120
document.getElementById("lowStock").innerText = 8
document.getElementById("pendingReceipts").innerText = 4
document.getElementById("pendingDeliveries").innerText = 6
const warehouseForm = document.getElementById("warehouseForm")

warehouseForm.addEventListener("submit", function(e){

e.preventDefault()

alert("Warehouse Added Successfully!")

})
const receiptForm = document.getElementById("receiptForm")

receiptForm.addEventListener("submit", function(e){

e.preventDefault()

alert("Receipt Validated. Stock Increased!")

})
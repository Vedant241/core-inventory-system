// Signup

const signupForm = document.getElementById("signupForm")

if(signupForm){

signupForm.addEventListener("submit", function(e){

e.preventDefault()

const name = document.getElementById("name").value
const email = document.getElementById("signupEmail").value
const password = document.getElementById("signupPassword").value

const user = {
name,
email,
password
}

localStorage.setItem("user", JSON.stringify(user))

alert("Account Created Successfully")

window.location.href = "login.html"

})

}


// Login

const loginForm = document.getElementById("loginForm")

if(loginForm){

loginForm.addEventListener("submit", function(e){

e.preventDefault()

const email = document.getElementById("email").value
const password = document.getElementById("password").value

const savedUser = JSON.parse(localStorage.getItem("user"))

if(savedUser && email === savedUser.email && password === savedUser.password){

alert("Login Successful")

window.location.href = "dashboard.html"

}
else{

alert("Invalid Login")

}

})

}


// Reset Password

const resetForm = document.getElementById("resetForm")

if(resetForm){

resetForm.addEventListener("submit", function(e){

e.preventDefault()

alert("OTP sent to your email (Demo)")

})

}
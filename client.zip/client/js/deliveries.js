const deliveryForm = document.getElementById("deliveryForm")

deliveryForm.addEventListener("submit", function(e){

e.preventDefault()

alert("Delivery Validated. Stock Reduced!")

})
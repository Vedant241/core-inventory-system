const adjustForm = document.getElementById("adjustForm")

adjustForm.addEventListener("submit", function(e){

e.preventDefault()

alert("Stock Adjusted Successfully!")

})
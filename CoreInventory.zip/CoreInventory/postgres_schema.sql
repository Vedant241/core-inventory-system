-- CoreInventory — PostgreSQL Database Schema
-- Run this in pgAdmin or psql to create the tables.

-- Users (for JWT auth)
CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  email VARCHAR(255) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  display_name VARCHAR(100) DEFAULT '',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Products
CREATE TABLE IF NOT EXISTS products (
  id SERIAL PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  sku VARCHAR(100) NOT NULL UNIQUE,
  category VARCHAR(100) DEFAULT 'Uncategorized',
  unit_of_measure VARCHAR(50) DEFAULT 'Unit',
  stock JSONB DEFAULT '{}'::jsonb,
  reorder_level INT DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Categories
CREATE TABLE IF NOT EXISTS categories (
  id SERIAL PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  description TEXT DEFAULT '',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Warehouses
CREATE TABLE IF NOT EXISTS warehouses (
  id SERIAL PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  address TEXT DEFAULT '',
  locations JSONB DEFAULT '[]'::jsonb,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Receipts (Incoming Stock)
CREATE TABLE IF NOT EXISTS receipts (
  id SERIAL PRIMARY KEY,
  receipt_no VARCHAR(50) NOT NULL UNIQUE,
  supplier VARCHAR(255) DEFAULT '',
  items JSONB DEFAULT '[]'::jsonb,
  warehouse_id VARCHAR(50) DEFAULT '',
  status VARCHAR(20) DEFAULT 'Draft',
  notes TEXT DEFAULT '',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  validated_at TIMESTAMP NULL,
  created_by INT NULL
);

-- Deliveries (Outgoing Stock)
CREATE TABLE IF NOT EXISTS deliveries (
  id SERIAL PRIMARY KEY,
  delivery_no VARCHAR(50) NOT NULL UNIQUE,
  customer VARCHAR(255) DEFAULT '',
  items JSONB DEFAULT '[]'::jsonb,
  warehouse_id VARCHAR(50) DEFAULT '',
  status VARCHAR(20) DEFAULT 'Draft',
  notes TEXT DEFAULT '',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  validated_at TIMESTAMP NULL,
  created_by INT NULL
);

-- Internal Transfers
CREATE TABLE IF NOT EXISTS transfers (
  id SERIAL PRIMARY KEY,
  transfer_no VARCHAR(50) NOT NULL UNIQUE,
  from_warehouse VARCHAR(50) NOT NULL,
  to_warehouse VARCHAR(50) NOT NULL,
  items JSONB DEFAULT '[]'::jsonb,
  status VARCHAR(20) DEFAULT 'Draft',
  notes TEXT DEFAULT '',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  validated_at TIMESTAMP NULL,
  created_by INT NULL
);

-- Stock Adjustments
CREATE TABLE IF NOT EXISTS adjustments (
  id SERIAL PRIMARY KEY,
  adjustment_no VARCHAR(50) NOT NULL UNIQUE,
  product_id INT NULL,
  product_name VARCHAR(255) DEFAULT '',
  warehouse_id VARCHAR(50) DEFAULT '',
  recorded_qty DECIMAL(10,2) DEFAULT 0,
  counted_qty DECIMAL(10,2) DEFAULT 0,
  difference DECIMAL(10,2) DEFAULT 0,
  reason TEXT DEFAULT '',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  created_by INT NULL
);

-- Stock Ledger (Move History)
CREATE TABLE IF NOT EXISTS stock_ledger (
  id SERIAL PRIMARY KEY,
  product_id INT NULL,
  product_name VARCHAR(255) DEFAULT '',
  type VARCHAR(20) NOT NULL,
  quantity DECIMAL(10,2) DEFAULT 0,
  from_location VARCHAR(50) NULL,
  to_location VARCHAR(50) NULL,
  reference_doc VARCHAR(50) NULL,
  user_id INT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Indexes
CREATE INDEX idx_receipts_status ON receipts(status);
CREATE INDEX idx_deliveries_status ON deliveries(status);
CREATE INDEX idx_transfers_status ON transfers(status);
CREATE INDEX idx_stock_ledger_created ON stock_ledger(created_at);
CREATE INDEX idx_stock_ledger_type ON stock_ledger(type);

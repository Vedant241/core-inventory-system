// Receipts page logic
let allProducts = [];
let allWarehouses = [];

window.onAppReady = async function () {
  await Promise.all([loadProducts(), loadWarehouses()]);
  loadReceipts();

  document.getElementById('newReceiptBtn').addEventListener('click', openModal);
  document.getElementById('closeReceiptModal').addEventListener('click', closeModal);
  document.getElementById('cancelReceiptModal').addEventListener('click', closeModal);
  document.getElementById('receiptForm').addEventListener('submit', createReceipt);
  document.getElementById('addReceiptItem').addEventListener('click', addItemRow);
  document.getElementById('receiptModal').addEventListener('click', (e) => {
    if (e.target === e.currentTarget) closeModal();
  });

  // Tab clicks
  document.querySelectorAll('#statusTabs .tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('#statusTabs .tab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      loadReceipts(tab.dataset.status);
    });
  });
};

async function loadProducts() {
  try { allProducts = await window.apiFetch('/api/products'); } catch (e) { }
}

async function loadWarehouses() {
  try {
    allWarehouses = await window.apiFetch('/api/warehouses');
    const select = document.getElementById('receiptWarehouse');
    allWarehouses.forEach(w => select.insertAdjacentHTML('beforeend', `<option value="${w.id}">${w.name}</option>`));
  } catch (e) { }
}

async function loadReceipts(status = '') {
  try {
    const url = status ? `/api/receipts?status=${status}` : '/api/receipts';
    const receipts = await window.apiFetch(url);
    renderReceipts(receipts);
  } catch (err) {
    showToast('Failed to load receipts', 'error');
  }
}

function renderReceipts(receipts) {
  const tbody = document.getElementById('receiptsBody');
  if (!receipts.length) {
    tbody.innerHTML = `<tr><td colspan="7"><div class="empty-state"><div class="empty-icon">📥</div><h3>No receipts</h3><p>Create a receipt when goods arrive from a vendor</p></div></td></tr>`;
    return;
  }
  const whMap = {};
  allWarehouses.forEach(w => whMap[w.id] = w.name);

  tbody.innerHTML = receipts.map(r => `
    <tr>
      <td style="color:var(--text-primary);font-weight:500;">${r.receiptNo}</td>
      <td>${r.supplier || '—'}</td>
      <td>${r.items ? r.items.length + ' item(s)' : '—'}</td>
      <td>${whMap[r.warehouseId] || r.warehouseId || '—'}</td>
      <td>${window.statusBadge(r.status)}</td>
      <td>${window.formatDate(r.createdAt)}</td>
      <td>
        ${r.status !== 'Done' && r.status !== 'Canceled' ? `<button class="btn btn-primary btn-sm" onclick="validateReceipt('${r.id}')">✓ Validate</button>` : ''}
      </td>
    </tr>
  `).join('');
}

function openModal() {
  document.getElementById('receiptModal').classList.add('active');
  document.getElementById('receiptForm').reset();
  document.getElementById('receiptItems').innerHTML = '';
  addItemRow();
}

function closeModal() {
  document.getElementById('receiptModal').classList.remove('active');
}

function addItemRow() {
  const container = document.getElementById('receiptItems');
  const row = document.createElement('div');
  row.className = 'item-row';
  row.innerHTML = `
    <select class="item-product" required>
      <option value="">Select product</option>
      ${allProducts.map(p => `<option value="${p.id}" data-name="${p.name}">${p.name} (${p.sku})</option>`).join('')}
    </select>
    <input type="number" class="item-qty" placeholder="Quantity" min="1" required>
    <button type="button" class="btn-icon danger" onclick="this.parentElement.remove()">✕</button>
  `;
  container.appendChild(row);
}

async function createReceipt(e) {
  e.preventDefault();
  const items = [];
  document.querySelectorAll('#receiptItems .item-row').forEach(row => {
    const select = row.querySelector('.item-product');
    const qty = row.querySelector('.item-qty').value;
    if (select.value && qty) {
      items.push({
        productId: select.value,
        productName: select.options[select.selectedIndex].dataset.name,
        quantity: Number(qty),
      });
    }
  });

  if (!items.length) { showToast('Add at least one item', 'warning'); return; }

  try {
    await window.apiFetch('/api/receipts', {
      method: 'POST',
      body: JSON.stringify({
        supplier: document.getElementById('receiptSupplier').value,
        warehouseId: document.getElementById('receiptWarehouse').value,
        notes: document.getElementById('receiptNotes').value,
        items,
      }),
    });
    showToast('Receipt created', 'success');
    closeModal();
    loadReceipts();
  } catch (err) {
    showToast(err.message, 'error');
  }
}

window.validateReceipt = async function (id) {
  if (!confirm('Validate this receipt? Stock levels will be updated.')) return;
  try {
    await window.apiFetch(`/api/receipts/${id}/validate`, { method: 'PUT' });
    showToast('Receipt validated — stock updated!', 'success');
    loadReceipts();
  } catch (err) {
    showToast(err.message, 'error');
  }
};

// Move History (Stock Ledger) page logic
let allLedger = [];
let allWarehouses = [];

window.onAppReady = async function () {
  await loadWarehouses();
  loadLedger();

  document.getElementById('filterType').addEventListener('change', filterLedger);
  document.getElementById('searchInput').addEventListener('input', filterLedger);
};

async function loadWarehouses() {
  try {
    allWarehouses = await window.apiFetch('/api/warehouses');
  } catch (e) { }
}

async function loadLedger() {
  try {
    allLedger = await window.apiFetch('/api/dashboard/stock-ledger');
    renderLedger(allLedger);
  } catch (err) {
    showToast('Failed to load move history', 'error');
  }
}

function renderLedger(items) {
  const tbody = document.getElementById('ledgerBody');
  const whMap = {};
  allWarehouses.forEach(w => whMap[w.id] = w.name);

  if (!items.length) {
    tbody.innerHTML = `<tr><td colspan="7"><div class="empty-state"><div class="empty-icon">📜</div><h3>No movements recorded</h3><p>Stock movements will appear here as you process operations</p></div></td></tr>`;
    return;
  }

  tbody.innerHTML = items.map(item => {
    const typeColors = { receipt: 'var(--accent)', delivery: 'var(--accent-blue)', transfer: 'var(--warning)', adjustment: 'var(--danger)' };
    const qtyColor = item.quantity > 0 ? 'var(--accent)' : 'var(--danger)';
    return `
      <tr>
        <td><span style="color:${typeColors[item.type] || 'var(--text-secondary)'};font-weight:600;text-transform:capitalize;">${item.type}</span></td>
        <td style="color:var(--text-primary);">${item.productName || item.productId}</td>
        <td style="color:${qtyColor};font-weight:600;">${item.quantity > 0 ? '+' : ''}${item.quantity}</td>
        <td>${whMap[item.fromLocation] || item.fromLocation || '—'}</td>
        <td>${whMap[item.toLocation] || item.toLocation || '—'}</td>
        <td><code style="background:var(--bg-glass);padding:2px 8px;border-radius:4px;font-size:12px;">${item.referenceDoc || '—'}</code></td>
        <td>${window.formatDate(item.timestamp)}</td>
      </tr>
    `;
  }).join('');
}

function filterLedger() {
  const type = document.getElementById('filterType').value;
  const search = document.getElementById('searchInput').value.toLowerCase();
  let filtered = allLedger;
  if (type) filtered = filtered.filter(l => l.type === type);
  if (search) filtered = filtered.filter(l => (l.productName || '').toLowerCase().includes(search));
  renderLedger(filtered);
}

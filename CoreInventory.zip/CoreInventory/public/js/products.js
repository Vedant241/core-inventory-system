// Products page logic
let allProducts = [];

window.onAppReady = async function () {
  loadProducts();
  loadCategories();
  loadWarehouses();

  document.getElementById('addProductBtn').addEventListener('click', () => openModal());
  document.getElementById('closeModal').addEventListener('click', closeModal);
  document.getElementById('cancelModal').addEventListener('click', closeModal);
  document.getElementById('productForm').addEventListener('submit', saveProduct);
  document.getElementById('searchInput').addEventListener('input', filterProducts);
  document.getElementById('categoryFilter').addEventListener('change', filterProducts);

  // Close modal on overlay click
  document.getElementById('productModal').addEventListener('click', (e) => {
    if (e.target === e.currentTarget) closeModal();
  });
};

async function loadProducts() {
  try {
    allProducts = await window.apiFetch('/api/products');
    renderProducts(allProducts);
  } catch (err) {
    showToast('Failed to load products', 'error');
  }
}

function renderProducts(products) {
  const tbody = document.getElementById('productsBody');
  if (!products.length) {
    tbody.innerHTML = `<tr><td colspan="7">
      <div class="empty-state">
        <div class="empty-icon">📦</div>
        <h3>No products yet</h3>
        <p>Add your first product to get started</p>
        <button class="btn btn-primary btn-sm" onclick="document.getElementById('addProductBtn').click()">+ Add Product</button>
      </div>
    </td></tr>`;
    return;
  }

  tbody.innerHTML = products.map(p => {
    const totalStock = p.stock ? Object.values(p.stock).reduce((a, b) => a + b, 0) : 0;
    const stockClass = totalStock === 0 ? 'stock-out' : (p.reorderLevel && totalStock <= p.reorderLevel ? 'stock-low' : '');
    return `
      <tr>
        <td style="color:var(--text-primary);font-weight:500;">${p.name}</td>
        <td><code style="background:var(--bg-glass);padding:2px 8px;border-radius:4px;font-size:12px;">${p.sku}</code></td>
        <td>${p.category || 'Uncategorized'}</td>
        <td>${p.unitOfMeasure || 'Unit'}</td>
        <td class="${stockClass}" style="font-weight:600;">${totalStock}</td>
        <td>${p.reorderLevel || 0}</td>
        <td>
          <button class="btn-icon" onclick="editProduct('${p.id}')" title="Edit">✏️</button>
          <button class="btn-icon danger" onclick="deleteProduct('${p.id}', '${p.name}')" title="Delete">🗑️</button>
        </td>
      </tr>
    `;
  }).join('');
}

function filterProducts() {
  const search = document.getElementById('searchInput').value.toLowerCase();
  const category = document.getElementById('categoryFilter').value;
  let filtered = allProducts;
  if (search) filtered = filtered.filter(p => p.name.toLowerCase().includes(search) || (p.sku && p.sku.toLowerCase().includes(search)));
  if (category) filtered = filtered.filter(p => p.category === category);
  renderProducts(filtered);
}

async function loadCategories() {
  try {
    const categories = await window.apiFetch('/api/products/categories/list');
    const filterSelect = document.getElementById('categoryFilter');
    const formSelect = document.getElementById('productCategory');
    categories.forEach(c => {
      filterSelect.insertAdjacentHTML('beforeend', `<option value="${c.name}">${c.name}</option>`);
      formSelect.insertAdjacentHTML('beforeend', `<option value="${c.name}">${c.name}</option>`);
    });
  } catch (err) {
    // Categories endpoint might not have data yet
  }
}

async function loadWarehouses() {
  try {
    const warehouses = await window.apiFetch('/api/warehouses');
    const select = document.getElementById('productWarehouse');
    warehouses.forEach(w => {
      select.insertAdjacentHTML('beforeend', `<option value="${w.id}">${w.name}</option>`);
    });
  } catch (err) { }
}

function openModal(product = null) {
  document.getElementById('productModal').classList.add('active');
  document.getElementById('modalTitle').textContent = product ? 'Edit Product' : 'Add Product';
  document.getElementById('initialStockRow').style.display = product ? 'none' : 'grid';

  if (product) {
    document.getElementById('productId').value = product.id;
    document.getElementById('productName').value = product.name;
    document.getElementById('productSku').value = product.sku;
    document.getElementById('productCategory').value = product.category || 'Uncategorized';
    document.getElementById('productUom').value = product.unitOfMeasure || 'Unit';
    document.getElementById('productReorder').value = product.reorderLevel || 0;
  } else {
    document.getElementById('productForm').reset();
    document.getElementById('productId').value = '';
  }
}

function closeModal() {
  document.getElementById('productModal').classList.remove('active');
}

async function saveProduct(e) {
  e.preventDefault();
  const id = document.getElementById('productId').value;
  const data = {
    name: document.getElementById('productName').value,
    sku: document.getElementById('productSku').value,
    category: document.getElementById('productCategory').value,
    unitOfMeasure: document.getElementById('productUom').value,
    reorderLevel: document.getElementById('productReorder').value || 0,
  };

  if (!id) {
    data.initialStock = document.getElementById('productInitialStock').value || 0;
    data.warehouseId = document.getElementById('productWarehouse').value;
  }

  try {
    if (id) {
      await window.apiFetch(`/api/products/${id}`, { method: 'PUT', body: JSON.stringify(data) });
      showToast('Product updated successfully', 'success');
    } else {
      await window.apiFetch('/api/products', { method: 'POST', body: JSON.stringify(data) });
      showToast('Product created successfully', 'success');
    }
    closeModal();
    loadProducts();
  } catch (err) {
    showToast(err.message, 'error');
  }
}

// Global functions for table buttons
window.editProduct = async function (id) {
  const product = allProducts.find(p => p.id == id);
  if (product) openModal(product);
};

window.deleteProduct = async function (id, name) {
  if (!confirm(`Delete product "${name}"? This cannot be undone.`)) return;
  try {
    await window.apiFetch(`/api/products/${id}`, { method: 'DELETE' });
    showToast('Product deleted', 'success');
    loadProducts();
  } catch (err) {
    showToast(err.message, 'error');
  }
};

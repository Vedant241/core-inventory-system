// Deliveries page logic
let allProducts = [];
let allWarehouses = [];

window.onAppReady = async function () {
  await Promise.all([loadProducts(), loadWarehouses()]);
  loadDeliveries();

  document.getElementById('newDeliveryBtn').addEventListener('click', openModal);
  document.getElementById('closeDeliveryModal').addEventListener('click', closeModal);
  document.getElementById('cancelDeliveryModal').addEventListener('click', closeModal);
  document.getElementById('deliveryForm').addEventListener('submit', createDelivery);
  document.getElementById('addDeliveryItem').addEventListener('click', addItemRow);
  document.getElementById('deliveryModal').addEventListener('click', (e) => {
    if (e.target === e.currentTarget) closeModal();
  });

  document.querySelectorAll('#statusTabs .tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('#statusTabs .tab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      loadDeliveries(tab.dataset.status);
    });
  });
};

async function loadProducts() {
  try { allProducts = await window.apiFetch('/api/products'); } catch (e) { }
}

async function loadWarehouses() {
  try {
    allWarehouses = await window.apiFetch('/api/warehouses');
    const select = document.getElementById('deliveryWarehouse');
    allWarehouses.forEach(w => select.insertAdjacentHTML('beforeend', `<option value="${w.id}">${w.name}</option>`));
  } catch (e) { }
}

async function loadDeliveries(status = '') {
  try {
    const url = status ? `/api/deliveries?status=${status}` : '/api/deliveries';
    const deliveries = await window.apiFetch(url);
    renderDeliveries(deliveries);
  } catch (err) {
    showToast('Failed to load deliveries', 'error');
  }
}

function renderDeliveries(deliveries) {
  const tbody = document.getElementById('deliveriesBody');
  const whMap = {};
  allWarehouses.forEach(w => whMap[w.id] = w.name);

  if (!deliveries.length) {
    tbody.innerHTML = `<tr><td colspan="7"><div class="empty-state"><div class="empty-icon">📤</div><h3>No deliveries</h3><p>Create a delivery when stock leaves the warehouse</p></div></td></tr>`;
    return;
  }

  tbody.innerHTML = deliveries.map(d => `
    <tr>
      <td style="color:var(--text-primary);font-weight:500;">${d.deliveryNo}</td>
      <td>${d.customer || '—'}</td>
      <td>${d.items ? d.items.length + ' item(s)' : '—'}</td>
      <td>${whMap[d.warehouseId] || d.warehouseId || '—'}</td>
      <td>${window.statusBadge(d.status)}</td>
      <td>${window.formatDate(d.createdAt)}</td>
      <td>
        ${d.status !== 'Done' && d.status !== 'Canceled' ? `<button class="btn btn-primary btn-sm" onclick="validateDelivery('${d.id}')">✓ Validate</button>` : ''}
      </td>
    </tr>
  `).join('');
}

function openModal() {
  document.getElementById('deliveryModal').classList.add('active');
  document.getElementById('deliveryForm').reset();
  document.getElementById('deliveryItems').innerHTML = '';
  addItemRow();
}

function closeModal() {
  document.getElementById('deliveryModal').classList.remove('active');
}

function addItemRow() {
  const container = document.getElementById('deliveryItems');
  const row = document.createElement('div');
  row.className = 'item-row';
  row.innerHTML = `
    <select class="item-product" required>
      <option value="">Select product</option>
      ${allProducts.map(p => {
    const totalStock = p.stock ? Object.values(p.stock).reduce((a, b) => a + b, 0) : 0;
    return `<option value="${p.id}" data-name="${p.name}">${p.name} (Stock: ${totalStock})</option>`;
  }).join('')}
    </select>
    <input type="number" class="item-qty" placeholder="Quantity" min="1" required>
    <button type="button" class="btn-icon danger" onclick="this.parentElement.remove()">✕</button>
  `;
  container.appendChild(row);
}

async function createDelivery(e) {
  e.preventDefault();
  const items = [];
  document.querySelectorAll('#deliveryItems .item-row').forEach(row => {
    const select = row.querySelector('.item-product');
    const qty = row.querySelector('.item-qty').value;
    if (select.value && qty) {
      items.push({
        productId: select.value,
        productName: select.options[select.selectedIndex].dataset.name,
        quantity: Number(qty),
      });
    }
  });

  if (!items.length) { showToast('Add at least one item', 'warning'); return; }

  try {
    await window.apiFetch('/api/deliveries', {
      method: 'POST',
      body: JSON.stringify({
        customer: document.getElementById('deliveryCustomer').value,
        warehouseId: document.getElementById('deliveryWarehouse').value,
        notes: document.getElementById('deliveryNotes').value,
        items,
      }),
    });
    showToast('Delivery order created', 'success');
    closeModal();
    loadDeliveries();
  } catch (err) {
    showToast(err.message, 'error');
  }
}

window.validateDelivery = async function (id) {
  if (!confirm('Validate this delivery? Stock levels will decrease.')) return;
  try {
    await window.apiFetch(`/api/deliveries/${id}/validate`, { method: 'PUT' });
    showToast('Delivery validated — stock updated!', 'success');
    loadDeliveries();
  } catch (err) {
    showToast(err.message, 'error');
  }
};

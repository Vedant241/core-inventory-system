// Dashboard page logic
window.onAppReady = async function () {
  loadDashboard();

  // Set current date
  const dateEl = document.getElementById('currentDate');
  if (dateEl) {
    dateEl.textContent = new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' });
  }

  // Filters
  document.getElementById('filterDocType')?.addEventListener('change', filterActivity);
  document.getElementById('filterStatus')?.addEventListener('change', filterActivity);
};

let allActivity = [];

async function loadDashboard() {
  try {
    const data = await window.apiFetch('/api/dashboard');

    document.getElementById('kpiTotalProducts').textContent = data.totalProducts || 0;
    document.getElementById('kpiLowStock').textContent = `${data.lowStockItems || 0} / ${data.outOfStockItems || 0}`;
    document.getElementById('kpiPendingReceipts').textContent = data.pendingReceipts || 0;
    document.getElementById('kpiPendingDeliveries').textContent = data.pendingDeliveries || 0;
    document.getElementById('kpiTransfers').textContent = data.pendingTransfers || 0;

    // Animate KPI values
    document.querySelectorAll('.kpi-value').forEach(el => {
      el.style.animation = 'fadeIn 0.5s ease';
    });

    allActivity = data.recentActivity || [];
    renderActivity(allActivity);
  } catch (err) {
    console.error('Dashboard load error:', err);
    showToast('Failed to load dashboard data', 'error');
  }
}

function renderActivity(items) {
  const list = document.getElementById('activityList');
  if (!items.length) {
    list.innerHTML = `
      <div class="empty-state">
        <div class="empty-icon">📊</div>
        <h3>No activity yet</h3>
        <p>Start by creating products and warehouse operations</p>
      </div>`;
    return;
  }

  list.innerHTML = items.map(item => `
    <li class="activity-item">
      <span class="activity-dot ${item.action}"></span>
      <div>
        <div class="activity-text">
          <strong>${(item.action || '').charAt(0).toUpperCase() + (item.action || '').slice(1)}</strong> —
          ${item.product || ''}:
          ${item.qty > 0 ? '+' : ''}${item.qty} units
          ${item.ref ? `(${item.ref})` : ''}
        </div>
        <div class="activity-time">${window.formatDate(item.date)}</div>
      </div>
    </li>
  `).join('');
}

function filterActivity() {
  const type = document.getElementById('filterDocType').value;
  const status = document.getElementById('filterStatus').value;
  let filtered = allActivity;
  if (type) filtered = filtered.filter(a => a.action === type);
  if (status) filtered = filtered.filter(a => (a.status || '').toLowerCase() === status.toLowerCase());
  renderActivity(filtered);
}

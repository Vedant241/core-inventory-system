// Auth page logic — API-based JWT authentication (no external SDK)

// DOM Elements
const loginForm = document.getElementById('loginForm');
const signupForm = document.getElementById('signupForm');
const resetForm = document.getElementById('resetForm');

// Form switch handlers
document.querySelectorAll('[data-switch]').forEach(el => {
  el.addEventListener('click', (e) => {
    e.preventDefault();
    const target = el.dataset.switch;
    document.querySelectorAll('.auth-form').forEach(f => f.classList.remove('active'));
    document.getElementById(target).classList.add('active');
    const msg = document.getElementById('authMessage');
    if (msg) msg.style.display = 'none';
  });
});

// Check if already logged in
if (localStorage.getItem('token')) {
  window.location.href = '/dashboard.html';
}

// Login
if (loginForm) {
  loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;
    const btn = loginForm.querySelector('button[type="submit"]');

    try {
      btn.disabled = true;
      btn.innerHTML = '<span class="spinner"></span> Signing in...';
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);

      localStorage.setItem('token', data.token);
      localStorage.setItem('user', JSON.stringify(data.user));
      window.location.href = '/dashboard.html';
    } catch (err) {
      showAuthError(err.message);
      btn.disabled = false;
      btn.textContent = 'Sign In';
    }
  });
}

// Signup — Step 1: Validate form + Send verification OTP to email
let signupData = {};

if (signupForm) {
  signupForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const name = document.getElementById('signupName').value;
    const email = document.getElementById('signupEmail').value;
    const password = document.getElementById('signupPassword').value;
    const confirmPassword = document.getElementById('signupConfirmPassword').value;
    const btn = signupForm.querySelector('button[type="submit"]');

    if (password !== confirmPassword) { showAuthError('Passwords do not match'); return; }
    if (password.length < 6) { showAuthError('Password must be at least 6 characters'); return; }

    // Store signup data for Step 2
    signupData = { name, email, password };

    try {
      btn.disabled = true;
      btn.innerHTML = '<span class="spinner"></span> Sending verification code...';
      const res = await fetch('/api/auth/send-signup-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);

      // Show OTP code if returned (fallback), otherwise show email message
      const otpCodeEl = document.getElementById('signupOtpCode');
      const otpMsgEl = document.getElementById('signupOtpMessage');
      if (data.otp) {
        otpCodeEl.textContent = data.otp;
        otpCodeEl.style.display = 'block';
        otpMsgEl.textContent = 'Email not configured — use this code:';
      } else {
        otpCodeEl.style.display = 'none';
        otpMsgEl.textContent = 'Check your email inbox for the verification code';
      }

      // Switch to OTP step
      document.querySelectorAll('.auth-form').forEach(f => f.classList.remove('active'));
      document.getElementById('signupOtpSection').classList.add('active');

      btn.disabled = false;
      btn.textContent = 'Send Verification Code';
    } catch (err) {
      showAuthError(err.message);
      btn.disabled = false;
      btn.textContent = 'Send Verification Code';
    }
  });
}

// Signup — Step 2: Verify OTP + Create account
const signupOtpForm = document.getElementById('signupOtpForm');
if (signupOtpForm) {
  signupOtpForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const otp = document.getElementById('signupOtpInput').value;
    const btn = signupOtpForm.querySelector('button[type="submit"]');

    try {
      btn.disabled = true;
      btn.innerHTML = '<span class="spinner"></span> Creating account...';
      const res = await fetch('/api/auth/signup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...signupData, otp }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);

      localStorage.setItem('token', data.token);
      localStorage.setItem('user', JSON.stringify(data.user));
      window.location.href = '/dashboard.html';
    } catch (err) {
      showAuthError(err.message);
      btn.disabled = false;
      btn.textContent = 'Verify & Create Account';
    }
  });
}

// Password Reset — Step 1: Request OTP
let resetEmail = '';

if (resetForm) {
  resetForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    resetEmail = document.getElementById('resetEmail').value;
    const btn = resetForm.querySelector('button[type="submit"]');

    try {
      btn.disabled = true;
      btn.innerHTML = '<span class="spinner"></span> Generating OTP...';
      const res = await fetch('/api/auth/request-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: resetEmail }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);

      // Show OTP on screen only if returned (fallback), otherwise show email message
      const otpCodeEl = document.getElementById('otpCode');
      const otpMsgEl = document.getElementById('otpMessage');
      if (data.otp) {
        // Fallback: SMTP not configured, show OTP directly
        otpCodeEl.textContent = data.otp;
        otpCodeEl.style.display = 'block';
        otpMsgEl.textContent = 'Email not configured — use this OTP code:';
      } else {
        // Email sent mode
        otpCodeEl.style.display = 'none';
        otpMsgEl.textContent = 'Check your email inbox for the OTP code';
      }
      document.querySelectorAll('.auth-form').forEach(f => f.classList.remove('active'));
      document.getElementById('otpSection').classList.add('active');

      btn.disabled = false;
      btn.textContent = 'Get OTP';
    } catch (err) {
      showAuthError(err.message);
      btn.disabled = false;
      btn.textContent = 'Get OTP';
    }
  });
}

// Password Reset — Step 2: Verify OTP + Set New Password
const otpForm = document.getElementById('otpForm');
if (otpForm) {
  otpForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const otp = document.getElementById('otpInput').value;
    const newPassword = document.getElementById('newPassword').value;
    const confirmNewPassword = document.getElementById('confirmNewPassword').value;
    const btn = otpForm.querySelector('button[type="submit"]');

    if (newPassword !== confirmNewPassword) { showAuthError('Passwords do not match'); return; }
    if (newPassword.length < 6) { showAuthError('Password must be at least 6 characters'); return; }

    try {
      btn.disabled = true;
      btn.innerHTML = '<span class="spinner"></span> Resetting...';
      const res = await fetch('/api/auth/verify-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: resetEmail, otp, newPassword }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);

      showAuthSuccess(data.message);
      // Switch back to login
      setTimeout(() => {
        document.querySelectorAll('.auth-form').forEach(f => f.classList.remove('active'));
        document.getElementById('loginSection').classList.add('active');
      }, 2000);
    } catch (err) {
      showAuthError(err.message);
      btn.disabled = false;
      btn.textContent = 'Reset Password';
    }
  });
}

function showAuthError(message) {
  const el = document.getElementById('authMessage');
  if (el) {
    el.textContent = message;
    el.className = 'auth-message error';
    el.style.display = 'block';
    setTimeout(() => { el.style.display = 'none'; }, 5000);
  }
}

function showAuthSuccess(message) {
  const el = document.getElementById('authMessage');
  if (el) {
    el.textContent = message;
    el.className = 'auth-message success';
    el.style.display = 'block';
    setTimeout(() => { el.style.display = 'none'; }, 5000);
  }
}

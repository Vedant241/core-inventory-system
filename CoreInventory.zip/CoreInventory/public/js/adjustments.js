// Adjustments page logic
let allProducts = [];
let allWarehouses = [];

window.onAppReady = async function () {
  await Promise.all([loadProducts(), loadWarehouses()]);
  loadAdjustments();

  document.getElementById('newAdjustmentBtn').addEventListener('click', openModal);
  document.getElementById('closeAdjModal').addEventListener('click', closeModal);
  document.getElementById('cancelAdjModal').addEventListener('click', closeModal);
  document.getElementById('adjustmentForm').addEventListener('submit', createAdjustment);
  document.getElementById('adjustmentModal').addEventListener('click', (e) => {
    if (e.target === e.currentTarget) closeModal();
  });

  // Update current stock display when product/warehouse changes
  document.getElementById('adjProduct').addEventListener('change', updateCurrentStock);
  document.getElementById('adjWarehouse').addEventListener('change', updateCurrentStock);
};

async function loadProducts() {
  try {
    allProducts = await window.apiFetch('/api/products');
    const select = document.getElementById('adjProduct');
    allProducts.forEach(p => select.insertAdjacentHTML('beforeend', `<option value="${p.id}" data-name="${p.name}">${p.name} (${p.sku})</option>`));
  } catch (e) { }
}

async function loadWarehouses() {
  try {
    allWarehouses = await window.apiFetch('/api/warehouses');
    const select = document.getElementById('adjWarehouse');
    allWarehouses.forEach(w => select.insertAdjacentHTML('beforeend', `<option value="${w.id}">${w.name}</option>`));
  } catch (e) { }
}

function updateCurrentStock() {
  const productId = document.getElementById('adjProduct').value;
  const warehouseId = document.getElementById('adjWarehouse').value;
  const display = document.getElementById('adjCurrentStock');

  if (!productId || !warehouseId) {
    display.textContent = 'Select product & warehouse';
    return;
  }

  const product = allProducts.find(p => p.id == productId);
  if (product) {
    const stock = product.stock ? (product.stock[warehouseId] || 0) : 0;
    display.textContent = `${stock} ${product.unitOfMeasure || 'units'}`;
    display.style.color = stock === 0 ? 'var(--danger)' : 'var(--text-primary)';
  }
}

async function loadAdjustments() {
  try {
    const adjustments = await window.apiFetch('/api/adjustments');
    renderAdjustments(adjustments);
  } catch (err) {
    showToast('Failed to load adjustments', 'error');
  }
}

function renderAdjustments(adjustments) {
  const tbody = document.getElementById('adjustmentsBody');
  const whMap = {};
  allWarehouses.forEach(w => whMap[w.id] = w.name);

  if (!adjustments.length) {
    tbody.innerHTML = `<tr><td colspan="8"><div class="empty-state"><div class="empty-icon">📋</div><h3>No adjustments</h3><p>Adjust stock when physical count differs from records</p></div></td></tr>`;
    return;
  }

  tbody.innerHTML = adjustments.map(a => {
    const diffColor = a.difference > 0 ? 'var(--accent)' : a.difference < 0 ? 'var(--danger)' : 'var(--text-secondary)';
    return `
      <tr>
        <td style="color:var(--text-primary);font-weight:500;">${a.adjustmentNo}</td>
        <td>${a.productName}</td>
        <td>${whMap[a.warehouseId] || a.warehouseId}</td>
        <td>${a.recordedQty}</td>
        <td>${a.countedQty}</td>
        <td style="color:${diffColor};font-weight:600;">${a.difference > 0 ? '+' : ''}${a.difference}</td>
        <td>${a.reason || '—'}</td>
        <td>${window.formatDate(a.createdAt)}</td>
      </tr>
    `;
  }).join('');
}

function openModal() {
  document.getElementById('adjustmentModal').classList.add('active');
  document.getElementById('adjustmentForm').reset();
  document.getElementById('adjCurrentStock').textContent = 'Select product & warehouse';
}

function closeModal() {
  document.getElementById('adjustmentModal').classList.remove('active');
}

async function createAdjustment(e) {
  e.preventDefault();
  const productId = document.getElementById('adjProduct').value;
  const select = document.getElementById('adjProduct');
  const productName = select.options[select.selectedIndex].dataset.name;

  try {
    await window.apiFetch('/api/adjustments', {
      method: 'POST',
      body: JSON.stringify({
        productId,
        productName,
        warehouseId: document.getElementById('adjWarehouse').value,
        countedQty: Number(document.getElementById('adjCountedQty').value),
        reason: document.getElementById('adjReason').value,
      }),
    });
    showToast('Stock adjusted successfully', 'success');
    closeModal();
    loadAdjustments();
    // Refresh products data for updated stock
    loadProducts();
  } catch (err) {
    showToast(err.message, 'error');
  }
}

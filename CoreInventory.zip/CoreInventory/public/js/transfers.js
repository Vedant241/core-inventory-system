// Transfers page logic
let allProducts = [];
let allWarehouses = [];

window.onAppReady = async function () {
  await Promise.all([loadProducts(), loadWarehouses()]);
  loadTransfers();

  document.getElementById('newTransferBtn').addEventListener('click', openModal);
  document.getElementById('closeTransferModal').addEventListener('click', closeModal);
  document.getElementById('cancelTransferModal').addEventListener('click', closeModal);
  document.getElementById('transferForm').addEventListener('submit', createTransfer);
  document.getElementById('addTransferItem').addEventListener('click', addItemRow);
  document.getElementById('transferModal').addEventListener('click', (e) => {
    if (e.target === e.currentTarget) closeModal();
  });

  document.querySelectorAll('#statusTabs .tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('#statusTabs .tab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      loadTransfers(tab.dataset.status);
    });
  });
};

async function loadProducts() {
  try { allProducts = await window.apiFetch('/api/products'); } catch (e) { }
}

async function loadWarehouses() {
  try {
    allWarehouses = await window.apiFetch('/api/warehouses');
    ['transferFrom', 'transferTo'].forEach(id => {
      const select = document.getElementById(id);
      allWarehouses.forEach(w => select.insertAdjacentHTML('beforeend', `<option value="${w.id}">${w.name}</option>`));
    });
  } catch (e) { }
}

async function loadTransfers(status = '') {
  try {
    const url = status ? `/api/transfers?status=${status}` : '/api/transfers';
    const transfers = await window.apiFetch(url);
    renderTransfers(transfers);
  } catch (err) {
    showToast('Failed to load transfers', 'error');
  }
}

function renderTransfers(transfers) {
  const tbody = document.getElementById('transfersBody');
  const whMap = {};
  allWarehouses.forEach(w => whMap[w.id] = w.name);

  if (!transfers.length) {
    tbody.innerHTML = `<tr><td colspan="7"><div class="empty-state"><div class="empty-icon">🔄</div><h3>No transfers</h3><p>Move stock between warehouses or locations</p></div></td></tr>`;
    return;
  }

  tbody.innerHTML = transfers.map(t => `
    <tr>
      <td style="color:var(--text-primary);font-weight:500;">${t.transferNo}</td>
      <td>${whMap[t.fromWarehouse] || t.fromWarehouse}</td>
      <td>${whMap[t.toWarehouse] || t.toWarehouse}</td>
      <td>${t.items ? t.items.length + ' item(s)' : '—'}</td>
      <td>${window.statusBadge(t.status)}</td>
      <td>${window.formatDate(t.createdAt)}</td>
      <td>
        ${t.status !== 'Done' ? `<button class="btn btn-primary btn-sm" onclick="validateTransfer('${t.id}')">✓ Execute</button>` : ''}
      </td>
    </tr>
  `).join('');
}

function openModal() {
  document.getElementById('transferModal').classList.add('active');
  document.getElementById('transferForm').reset();
  document.getElementById('transferItems').innerHTML = '';
  addItemRow();
}

function closeModal() {
  document.getElementById('transferModal').classList.remove('active');
}

function addItemRow() {
  const container = document.getElementById('transferItems');
  const row = document.createElement('div');
  row.className = 'item-row';
  row.innerHTML = `
    <select class="item-product" required>
      <option value="">Select product</option>
      ${allProducts.map(p => `<option value="${p.id}" data-name="${p.name}">${p.name} (${p.sku})</option>`).join('')}
    </select>
    <input type="number" class="item-qty" placeholder="Quantity" min="1" required>
    <button type="button" class="btn-icon danger" onclick="this.parentElement.remove()">✕</button>
  `;
  container.appendChild(row);
}

async function createTransfer(e) {
  e.preventDefault();
  const from = document.getElementById('transferFrom').value;
  const to = document.getElementById('transferTo').value;
  if (from === to) { showToast('Source and destination must be different', 'warning'); return; }

  const items = [];
  document.querySelectorAll('#transferItems .item-row').forEach(row => {
    const select = row.querySelector('.item-product');
    const qty = row.querySelector('.item-qty').value;
    if (select.value && qty) {
      items.push({ productId: select.value, productName: select.options[select.selectedIndex].dataset.name, quantity: Number(qty) });
    }
  });

  if (!items.length) { showToast('Add at least one item', 'warning'); return; }

  try {
    await window.apiFetch('/api/transfers', {
      method: 'POST',
      body: JSON.stringify({ fromWarehouse: from, toWarehouse: to, items, notes: document.getElementById('transferNotes').value }),
    });
    showToast('Transfer created', 'success');
    closeModal();
    loadTransfers();
  } catch (err) {
    showToast(err.message, 'error');
  }
}

window.validateTransfer = async function (id) {
  if (!confirm('Execute this transfer? Stock will move between warehouses.')) return;
  try {
    await window.apiFetch(`/api/transfers/${id}/validate`, { method: 'PUT' });
    showToast('Transfer completed!', 'success');
    loadTransfers();
  } catch (err) {
    showToast(err.message, 'error');
  }
};

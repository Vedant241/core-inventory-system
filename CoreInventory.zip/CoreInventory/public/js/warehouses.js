// Warehouses page logic
let allWarehouses = [];

window.onAppReady = function () {
  loadWarehouses();

  document.getElementById('addWarehouseBtn').addEventListener('click', () => openModal());
  document.getElementById('closeWhModal').addEventListener('click', closeModal);
  document.getElementById('cancelWhModal').addEventListener('click', closeModal);
  document.getElementById('warehouseForm').addEventListener('submit', saveWarehouse);
  document.getElementById('warehouseModal').addEventListener('click', (e) => {
    if (e.target === e.currentTarget) closeModal();
  });
};

async function loadWarehouses() {
  try {
    allWarehouses = await window.apiFetch('/api/warehouses');
    renderWarehouses(allWarehouses);
  } catch (err) {
    showToast('Failed to load warehouses', 'error');
  }
}

function renderWarehouses(warehouses) {
  const container = document.getElementById('warehousesList');
  if (!warehouses.length) {
    container.innerHTML = `
      <div class="empty-state" style="grid-column: 1 / -1;">
        <div class="empty-icon">🏭</div>
        <h3>No warehouses configured</h3>
        <p>Add your first warehouse to organize your stock</p>
        <button class="btn btn-primary btn-sm" onclick="document.getElementById('addWarehouseBtn').click()">+ Add Warehouse</button>
      </div>`;
    return;
  }

  container.innerHTML = warehouses.map(w => `
    <div class="card" style="position:relative;">
      <div style="display:flex;align-items:start;justify-content:space-between;margin-bottom:16px;">
        <div>
          <div style="font-size:28px;margin-bottom:8px;">🏭</div>
          <h3 style="font-size:18px;font-weight:600;color:var(--text-primary);">${w.name}</h3>
        </div>
        <div style="display:flex;gap:6px;">
          <button class="btn-icon" onclick="editWarehouse('${w.id}')" title="Edit">✏️</button>
          <button class="btn-icon danger" onclick="deleteWarehouse('${w.id}', '${w.name}')" title="Delete">🗑️</button>
        </div>
      </div>
      ${w.address ? `<p style="font-size:13px;color:var(--text-secondary);margin-bottom:12px;">📍 ${w.address}</p>` : ''}
      ${w.locations && w.locations.length ? `
        <div style="margin-top:8px;">
          <span style="font-size:11px;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.5px;">Locations</span>
          <div style="display:flex;flex-wrap:wrap;gap:6px;margin-top:6px;">
            ${w.locations.map(l => `<span style="background:var(--bg-glass);padding:4px 10px;border-radius:6px;font-size:12px;color:var(--text-secondary);border:1px solid var(--border-color);">${l}</span>`).join('')}
          </div>
        </div>
      ` : ''}
    </div>
  `).join('');
}

function openModal(warehouse = null) {
  document.getElementById('warehouseModal').classList.add('active');
  document.getElementById('whModalTitle').textContent = warehouse ? 'Edit Warehouse' : 'Add Warehouse';

  if (warehouse) {
    document.getElementById('whId').value = warehouse.id;
    document.getElementById('whName').value = warehouse.name;
    document.getElementById('whAddress').value = warehouse.address || '';
    document.getElementById('whLocations').value = (warehouse.locations || []).join(', ');
  } else {
    document.getElementById('warehouseForm').reset();
    document.getElementById('whId').value = '';
  }
}

function closeModal() {
  document.getElementById('warehouseModal').classList.remove('active');
}

async function saveWarehouse(e) {
  e.preventDefault();
  const id = document.getElementById('whId').value;
  const locations = document.getElementById('whLocations').value
    .split(',').map(l => l.trim()).filter(Boolean);

  const data = {
    name: document.getElementById('whName').value,
    address: document.getElementById('whAddress').value,
    locations,
  };

  try {
    if (id) {
      await window.apiFetch(`/api/warehouses/${id}`, { method: 'PUT', body: JSON.stringify(data) });
      showToast('Warehouse updated', 'success');
    } else {
      await window.apiFetch('/api/warehouses', { method: 'POST', body: JSON.stringify(data) });
      showToast('Warehouse created', 'success');
    }
    closeModal();
    loadWarehouses();
  } catch (err) {
    showToast(err.message, 'error');
  }
}

window.editWarehouse = function (id) {
  const wh = allWarehouses.find(w => w.id == id);
  if (wh) openModal(wh);
};

window.deleteWarehouse = async function (id, name) {
  if (!confirm(`Delete warehouse "${name}"?`)) return;
  try {
    await window.apiFetch(`/api/warehouses/${id}`, { method: 'DELETE' });
    showToast('Warehouse deleted', 'success');
    loadWarehouses();
  } catch (err) {
    showToast(err.message, 'error');
  }
};

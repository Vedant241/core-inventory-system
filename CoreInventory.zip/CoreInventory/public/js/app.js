// Shared App Shell — Sidebar, Header, Auth Guard, Toast system
// No external SDK — uses JWT token from localStorage

let currentUser = null;
let authToken = null;

// Auth guard — redirect to login if no token
authToken = localStorage.getItem('token');
const storedUser = localStorage.getItem('user');

if (!authToken || !storedUser) {
  window.location.href = '/index.html';
} else {
  currentUser = JSON.parse(storedUser);
  window.authToken = authToken;
  window.currentUser = currentUser;

  // Init sidebar and trigger app ready
  document.addEventListener('DOMContentLoaded', () => {
    initSidebar();
    if (typeof window.onAppReady === 'function') {
      window.onAppReady();
    }
  });
}

// Get auth headers helper
window.getAuthHeaders = () => ({
  'Content-Type': 'application/json',
  'Authorization': `Bearer ${authToken}`,
});

// Sidebar HTML
function initSidebar() {
  const currentPath = window.location.pathname;
  const displayName = currentUser.displayName || currentUser.email.split('@')[0];
  const userInitial = displayName.charAt(0).toUpperCase();

  const sidebarHTML = `
    <div class="sidebar" id="sidebar">
      <div class="sidebar-brand">
        <h1>CoreInventory</h1>
        <span>Inventory Management</span>
      </div>
      <nav class="sidebar-nav">
        <div class="nav-section">
          <div class="nav-section-title">Overview</div>
          <a href="/dashboard.html" class="nav-item ${currentPath.includes('dashboard') ? 'active' : ''}">
            <span class="icon">📊</span>
            <span>Dashboard</span>
          </a>
        </div>
        <div class="nav-section">
          <div class="nav-section-title">Products</div>
          <a href="/products.html" class="nav-item ${currentPath.includes('products') ? 'active' : ''}">
            <span class="icon">📦</span>
            <span>All Products</span>
          </a>
        </div>
        <div class="nav-section">
          <div class="nav-section-title">Operations</div>
          <a href="/receipts.html" class="nav-item ${currentPath.includes('receipts') ? 'active' : ''}">
            <span class="icon">📥</span>
            <span>Receipts</span>
          </a>
          <a href="/deliveries.html" class="nav-item ${currentPath.includes('deliveries') ? 'active' : ''}">
            <span class="icon">📤</span>
            <span>Delivery Orders</span>
          </a>
          <a href="/transfers.html" class="nav-item ${currentPath.includes('transfers') ? 'active' : ''}">
            <span class="icon">🔄</span>
            <span>Internal Transfers</span>
          </a>
          <a href="/adjustments.html" class="nav-item ${currentPath.includes('adjustments') ? 'active' : ''}">
            <span class="icon">📋</span>
            <span>Inventory Adjustments</span>
          </a>
          <a href="/move-history.html" class="nav-item ${currentPath.includes('move-history') ? 'active' : ''}">
            <span class="icon">📜</span>
            <span>Move History</span>
          </a>
        </div>
        <div class="nav-section">
          <div class="nav-section-title">Settings</div>
          <a href="/warehouses.html" class="nav-item ${currentPath.includes('warehouses') ? 'active' : ''}">
            <span class="icon">🏭</span>
            <span>Warehouses</span>
          </a>
        </div>
      </nav>
      <div class="sidebar-footer">
        <a href="/profile.html" class="user-info" style="text-decoration:none;">
          <div class="user-avatar">${userInitial}</div>
          <div class="user-details">
            <div class="name">${displayName}</div>
            <div class="role">Inventory Manager</div>
          </div>
        </a>
        <button class="btn btn-secondary btn-sm btn-block" id="logoutBtn" style="margin-top: 10px;">
          🚪 Logout
        </button>
      </div>
    </div>
  `;

  const layout = document.querySelector('.app-layout');
  if (layout) layout.insertAdjacentHTML('afterbegin', sidebarHTML);

  const hamburger = document.querySelector('.hamburger');
  if (hamburger) {
    hamburger.addEventListener('click', () => {
      document.getElementById('sidebar').classList.toggle('open');
    });
  }

  document.querySelectorAll('.nav-item').forEach(item => {
    item.addEventListener('click', () => {
      if (window.innerWidth <= 768) document.getElementById('sidebar').classList.remove('open');
    });
  });

  document.getElementById('logoutBtn').addEventListener('click', () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    window.location.href = '/index.html';
  });
}

// Toast notification system
window.showToast = function(message, type = 'info') {
  let container = document.querySelector('.toast-container');
  if (!container) {
    container = document.createElement('div');
    container.className = 'toast-container';
    document.body.appendChild(container);
  }

  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  const icons = { success: '✅', error: '❌', info: 'ℹ️', warning: '⚠️' };
  toast.innerHTML = `<span>${icons[type] || ''}</span><span>${message}</span>`;
  container.appendChild(toast);

  setTimeout(() => {
    toast.classList.add('removing');
    setTimeout(() => toast.remove(), 300);
  }, 4000);
};

// API fetch helper
window.apiFetch = async function(url, options = {}) {
  const defaults = { headers: window.getAuthHeaders() };
  const config = { ...defaults, ...options, headers: { ...defaults.headers, ...options.headers } };
  const response = await fetch(url, config);

  if (response.status === 401) {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    window.location.href = '/index.html';
    return;
  }

  if (!response.ok) {
    const err = await response.json().catch(() => ({ error: 'Request failed' }));
    throw new Error(err.error || 'Request failed');
  }

  return response.json();
};

// Format date helper
window.formatDate = function(dateStr) {
  if (!dateStr) return '—';
  const d = new Date(dateStr);
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit' });
};

// Status badge helper
window.statusBadge = function(status) {
  const cls = (status || 'Draft').toLowerCase();
  return `<span class="badge badge-${cls}">${status || 'Draft'}</span>`;
};

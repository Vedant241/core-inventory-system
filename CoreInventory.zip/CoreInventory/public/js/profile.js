// Profile page logic — API-based

window.onAppReady = function() {
  const user = window.currentUser;
  const displayName = user.displayName || '';

  document.getElementById('profileAvatar').textContent = displayName
    ? displayName.charAt(0).toUpperCase()
    : (user.email || '?').charAt(0).toUpperCase();
  document.getElementById('profileName').value = displayName;
  document.getElementById('profileEmail').value = user.email || '';

  document.getElementById('updateProfileBtn').addEventListener('click', async () => {
    const newName = document.getElementById('profileName').value.trim();
    if (!newName) { showToast('Name cannot be empty', 'warning'); return; }

    try {
      await window.apiFetch('/api/auth/profile', {
        method: 'PUT',
        body: JSON.stringify({ displayName: newName }),
      });
      // Update locally
      user.displayName = newName;
      localStorage.setItem('user', JSON.stringify(user));
      showToast('Profile updated!', 'success');
      document.getElementById('profileAvatar').textContent = newName.charAt(0).toUpperCase();
    } catch (err) {
      showToast('Failed to update profile', 'error');
    }
  });

  document.getElementById('logoutProfileBtn').addEventListener('click', () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    window.location.href = '/index.html';
  });
};

const { Pool } = require('pg');

const pool = new Pool({
  host: process.env.DB_HOST || 'localhost',
  port: Number(process.env.DB_PORT) || 5432,
  user: process.env.DB_USER || 'postgres',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'coreinventory',
});

// Test connection
pool.connect()
  .then(client => {
    client.release();
    console.log('✅ Connected to PostgreSQL');
  })
  .catch(err => {
    console.error('❌ PostgreSQL connection error:', err.stack);
  });

module.exports = { pool };

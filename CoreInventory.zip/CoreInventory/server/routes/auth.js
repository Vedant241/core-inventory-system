const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { pool } = require('../db');
const verifyAuth = require('../middleware/auth');

function generateToken(user) {
  return jwt.sign(
    { id: user.id, email: user.email, displayName: user.display_name },
    process.env.JWT_SECRET,
    { expiresIn: '7d' }
  );
}

// POST /api/auth/send-signup-otp — send verification OTP to email before signup
router.post('/send-signup-otp', async (req, res) => {
  try {
    const { email } = req.body;
    if (!email) return res.status(400).json({ error: 'Email is required' });

    // Check if email already registered
    const { rows: existing } = await pool.query('SELECT id FROM users WHERE email = $1', [email]);
    if (existing.length > 0) return res.status(400).json({ error: 'Email already registered' });

    // Generate 6-digit OTP
    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    const expiresAt = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes

    // Invalidate previous OTPs for this email
    await pool.query('UPDATE password_resets SET used = true WHERE email = $1 AND used = false', [email]);

    // Store OTP
    await pool.query(
      'INSERT INTO password_resets (email, otp, expires_at) VALUES ($1, $2, $3)',
      [email, otp, expiresAt]
    );

    // Send OTP via email
    const { isSmtpConfigured, sendSignupOTPEmail } = require('../utils/email');
    if (isSmtpConfigured()) {
      await sendSignupOTPEmail(email, otp);
      res.json({ message: 'Verification code sent to your email!' });
    } else {
      // Fallback for dev — return OTP directly
      res.json({ message: 'OTP generated (email not configured)', otp });
    }
  } catch (err) {
    console.error('Send signup OTP error:', err);
    res.status(500).json({ error: 'Failed to send verification code' });
  }
});

// POST /api/auth/signup — create account (requires verified OTP)
router.post('/signup', async (req, res) => {
  try {
    const { name, email, password, otp } = req.body;
    if (!email || !password) return res.status(400).json({ error: 'Email and password are required' });
    if (!otp) return res.status(400).json({ error: 'Verification code is required' });
    if (password.length < 6) return res.status(400).json({ error: 'Password must be at least 6 characters' });

    // Verify OTP
    const { rows: otpRows } = await pool.query(
      'SELECT id FROM password_resets WHERE email = $1 AND otp = $2 AND used = false AND expires_at > NOW() ORDER BY created_at DESC LIMIT 1',
      [email, otp]
    );
    if (otpRows.length === 0) return res.status(400).json({ error: 'Invalid or expired verification code' });

    // Mark OTP as used
    await pool.query('UPDATE password_resets SET used = true WHERE id = $1', [otpRows[0].id]);

    // Check if email already registered (double-check)
    const { rows: existing } = await pool.query('SELECT id FROM users WHERE email = $1', [email]);
    if (existing.length > 0) return res.status(400).json({ error: 'Email already registered' });

    const hashedPassword = await bcrypt.hash(password, 10);
    const { rows: result } = await pool.query(
      'INSERT INTO users (email, password_hash, display_name) VALUES ($1, $2, $3) RETURNING id',
      [email, hashedPassword, name || email.split('@')[0]]
    );

    const user = { id: result[0].id, email, display_name: name || email.split('@')[0] };
    const token = generateToken(user);
    res.status(201).json({ token, user: { id: user.id, email, displayName: user.display_name } });
  } catch (err) {
    console.error('Signup error:', err);
    res.status(500).json({ error: 'Failed to create account' });
  }
});

// POST /api/auth/login
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ error: 'Email and password are required' });

    const { rows } = await pool.query('SELECT * FROM users WHERE email = $1', [email]);
    if (rows.length === 0) return res.status(401).json({ error: 'Invalid email or password' });

    const user = rows[0];
    const valid = await bcrypt.compare(password, user.password_hash);
    if (!valid) return res.status(401).json({ error: 'Invalid email or password' });

    const token = generateToken(user);
    res.json({ token, user: { id: user.id, email: user.email, displayName: user.display_name } });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ error: 'Failed to log in' });
  }
});

// GET /api/auth/me — get current user
router.get('/me', verifyAuth, async (req, res) => {
  try {
    const { rows } = await pool.query('SELECT id, email, display_name FROM users WHERE id = $1', [req.user.id]);
    if (rows.length === 0) return res.status(404).json({ error: 'User not found' });
    const u = rows[0];
    res.json({ id: u.id, email: u.email, displayName: u.display_name });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch user' });
  }
});

// PUT /api/auth/profile — update display name
router.put('/profile', verifyAuth, async (req, res) => {
  try {
    const { displayName } = req.body;
    if (!displayName) return res.status(400).json({ error: 'Display name is required' });
    await pool.query('UPDATE users SET display_name = $1 WHERE id = $2', [displayName, req.user.id]);
    res.json({ message: 'Profile updated', displayName });
  } catch (err) {
    res.status(500).json({ error: 'Failed to update profile' });
  }
});

// POST /api/auth/request-otp — generate OTP and send via email
router.post('/request-otp', async (req, res) => {
  try {
    const { email } = req.body;
    if (!email) return res.status(400).json({ error: 'Email is required' });

    const { rows } = await pool.query('SELECT id FROM users WHERE email = $1', [email]);
    if (rows.length === 0) return res.status(404).json({ error: 'No account found with that email' });

    // Generate 6-digit OTP
    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    const expiresAt = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes

    // Invalidate any existing OTPs for this email
    await pool.query('UPDATE password_resets SET used = true WHERE email = $1 AND used = false', [email]);

    // Store new OTP
    await pool.query(
      'INSERT INTO password_resets (email, otp, expires_at) VALUES ($1, $2, $3)',
      [email, otp, expiresAt]
    );

    // Send OTP via email (if SMTP is properly configured)
    const smtpEmail = process.env.SMTP_EMAIL || '';
    const smtpPass = process.env.SMTP_PASSWORD || '';
    const smtpConfigured = smtpEmail && smtpPass && !smtpEmail.includes('your_') && !smtpPass.includes('your_');

    if (smtpConfigured) {
      const { sendOTPEmail } = require('../utils/email');
      await sendOTPEmail(email, otp);
      res.json({ message: 'OTP sent to your email. Check your inbox!' });
    } else {
      // Fallback: return OTP directly if email not configured
      res.json({ message: 'OTP generated (email not configured)', otp });
    }
  } catch (err) {
    console.error('Request OTP error:', err);
    res.status(500).json({ error: 'Failed to generate OTP' });
  }
});

// POST /api/auth/verify-otp — verify OTP and reset password
router.post('/verify-otp', async (req, res) => {
  try {
    const { email, otp, newPassword } = req.body;
    if (!email || !otp || !newPassword) return res.status(400).json({ error: 'Email, OTP, and new password are required' });
    if (newPassword.length < 6) return res.status(400).json({ error: 'Password must be at least 6 characters' });

    // Find valid, unused OTP
    const { rows } = await pool.query(
      'SELECT id FROM password_resets WHERE email = $1 AND otp = $2 AND used = false AND expires_at > NOW() ORDER BY created_at DESC LIMIT 1',
      [email, otp]
    );

    if (rows.length === 0) return res.status(400).json({ error: 'Invalid or expired OTP' });

    // Mark OTP as used
    await pool.query('UPDATE password_resets SET used = true WHERE id = $1', [rows[0].id]);

    // Update password
    const hashedPassword = await bcrypt.hash(newPassword, 10);
    await pool.query('UPDATE users SET password_hash = $1 WHERE email = $2', [hashedPassword, email]);

    res.json({ message: 'Password reset successfully. You can now sign in.' });
  } catch (err) {
    console.error('Verify OTP error:', err);
    res.status(500).json({ error: 'Failed to reset password' });
  }
});

module.exports = router;

const express = require('express');
const router = express.Router();
const verifyAuth = require('../middleware/auth');
const { pool } = require('../db');
const { logStockMovement } = require('../utils/stockLedger');

function mapReceipt(r) {
  return {
    id: r.id, receiptNo: r.receipt_no, supplier: r.supplier,
    items: typeof r.items === 'string' ? JSON.parse(r.items) : (r.items || []),
    warehouseId: r.warehouse_id, status: r.status, notes: r.notes,
    createdAt: r.created_at, validatedAt: r.validated_at,
  };
}

// GET /api/receipts
router.get('/', verifyAuth, async (req, res) => {
  try {
    const { status } = req.query;
    let query = 'SELECT * FROM receipts WHERE user_id = $1';
    const params = [req.user.id];
    if (status) { query += ' AND status = $2'; params.push(status); }
    query += ' ORDER BY created_at DESC';

    const { rows } = await pool.query(query, params);
    res.json(rows.map(mapReceipt));
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch receipts' });
  }
});

// GET /api/receipts/:id
router.get('/:id', verifyAuth, async (req, res) => {
  try {
    const { rows } = await pool.query('SELECT * FROM receipts WHERE id = $1 AND user_id = $2', [req.params.id, req.user.id]);
    if (rows.length === 0) return res.status(404).json({ error: 'Receipt not found' });
    res.json(mapReceipt(rows[0]));
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch receipt' });
  }
});

// POST /api/receipts
router.post('/', verifyAuth, async (req, res) => {
  try {
    const { supplier, items, warehouseId, notes } = req.body;
    if (!items || !items.length) return res.status(400).json({ error: 'Items are required' });

    const receiptNo = 'REC-' + Date.now().toString(36).toUpperCase();
    const { rows } = await pool.query(
      'INSERT INTO receipts (receipt_no, supplier, items, warehouse_id, status, notes, created_by, user_id) VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING id',
      [receiptNo, supplier || '', JSON.stringify(items), warehouseId || '', 'Draft', notes || '', req.user.id, req.user.id]
    );

    res.status(201).json({ id: rows[0].id, receiptNo, supplier, items, warehouseId, status: 'Draft', notes });
  } catch (err) {
    console.error('Receipts POST error:', err);
    res.status(500).json({ error: 'Failed to create receipt' });
  }
});

// PUT /api/receipts/:id/validate — increase stock
router.put('/:id/validate', verifyAuth, async (req, res) => {
  try {
    const { rows } = await pool.query('SELECT * FROM receipts WHERE id = $1 AND user_id = $2', [req.params.id, req.user.id]);
    if (rows.length === 0) return res.status(404).json({ error: 'Receipt not found' });
    const receipt = rows[0];
    if (receipt.status === 'Done') return res.status(400).json({ error: 'Receipt already validated' });

    const items = typeof receipt.items === 'string' ? JSON.parse(receipt.items) : (receipt.items || []);
    const warehouseId = receipt.warehouse_id || 'default';

    for (const item of items) {
      const { rows: pRows } = await pool.query('SELECT stock FROM products WHERE id = $1 AND user_id = $2', [item.productId, req.user.id]);
      if (pRows.length > 0) {
        let currentStock = {};
        if (typeof pRows[0].stock === 'string') {
          try { currentStock = JSON.parse(pRows[0].stock); } catch (e) { }
        } else if (pRows[0].stock) {
          currentStock = pRows[0].stock;
        }
        currentStock[warehouseId] = (currentStock[warehouseId] || 0) + Number(item.quantity);
        await pool.query('UPDATE products SET stock = $1 WHERE id = $2 AND user_id = $3', [JSON.stringify(currentStock), item.productId, req.user.id]);
      }

      await logStockMovement({
        productId: item.productId, productName: item.productName,
        type: 'receipt', quantity: Number(item.quantity),
        toLocation: warehouseId, referenceDoc: receipt.receipt_no, userId: req.user.id,
      });
    }

    await pool.query('UPDATE receipts SET status = $1, validated_at = NOW() WHERE id = $2 AND user_id = $3', ['Done', req.params.id, req.user.id]);
    res.json({ message: 'Receipt validated, stock updated', receiptNo: receipt.receipt_no });
  } catch (err) {
    console.error('Receipt validate error:', err);
    res.status(500).json({ error: 'Failed to validate receipt' });
  }
});

module.exports = router;

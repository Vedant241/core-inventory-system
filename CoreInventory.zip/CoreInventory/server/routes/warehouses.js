const express = require('express');
const router = express.Router();
const verifyAuth = require('../middleware/auth');
const { pool } = require('../db');

// GET /api/warehouses
router.get('/', verifyAuth, async (req, res) => {
  try {
    const { rows } = await pool.query('SELECT * FROM warehouses WHERE user_id = $1 ORDER BY name', [req.user.id]);
    res.json(rows.map(w => ({
      id: w.id,
      name: w.name,
      address: w.address,
      locations: typeof w.locations === 'string' ? JSON.parse(w.locations) : (w.locations || []),
      createdAt: w.created_at
    })));
  } catch (err) {
    console.error('Warehouses GET error:', err);
    res.status(500).json({ error: 'Failed to fetch warehouses' });
  }
});

// POST /api/warehouses
router.post('/', verifyAuth, async (req, res) => {
  try {
    const { name, address, locations } = req.body;
    if (!name) return res.status(400).json({ error: 'Warehouse name is required' });

    const locsString = Array.isArray(locations) ? JSON.stringify(locations) : '[]';

    const { rows } = await pool.query(
      'INSERT INTO warehouses (name, address, locations, user_id) VALUES ($1, $2, $3, $4) RETURNING id',
      [name, address || '', locsString, req.user.id]
    );

    res.status(201).json({
      id: rows[0].id, name, address, locations: Array.isArray(locations) ? locations : []
    });
  } catch (err) {
    console.error('Warehouses POST error:', err);
    res.status(500).json({ error: 'Failed to create warehouse' });
  }
});

// PUT /api/warehouses/:id
router.put('/:id', verifyAuth, async (req, res) => {
  try {
    const { name, address, locations } = req.body;
    const locsString = Array.isArray(locations) ? JSON.stringify(locations) : '[]';

    await pool.query(
      'UPDATE warehouses SET name = $1, address = $2, locations = $3 WHERE id = $4 AND user_id = $5',
      [name, address || '', locsString, req.params.id, req.user.id]
    );
    res.json({ id: req.params.id, name, address, locations: Array.isArray(locations) ? locations : [] });
  } catch (err) {
    console.error('Warehouses PUT error:', err);
    res.status(500).json({ error: 'Failed to update warehouse' });
  }
});

// DELETE /api/warehouses/:id
router.delete('/:id', verifyAuth, async (req, res) => {
  try {
    await pool.query('DELETE FROM warehouses WHERE id = $1 AND user_id = $2', [req.params.id, req.user.id]);
    res.json({ message: 'Warehouse deleted' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to delete warehouse' });
  }
});

module.exports = router;

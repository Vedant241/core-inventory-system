const express = require('express');
const router = express.Router();
const verifyAuth = require('../middleware/auth');
const { pool } = require('../db');
const { logStockMovement } = require('../utils/stockLedger');

function mapTransfer(t) {
  return {
    id: t.id, transferNo: t.transfer_no, fromWarehouse: t.from_warehouse,
    toWarehouse: t.to_warehouse,
    items: typeof t.items === 'string' ? JSON.parse(t.items) : (t.items || []),
    status: t.status, notes: t.notes, createdAt: t.created_at, validatedAt: t.validated_at,
  };
}

// GET /api/transfers
router.get('/', verifyAuth, async (req, res) => {
  try {
    const { status } = req.query;
    let query = 'SELECT * FROM transfers WHERE user_id = $1';
    const params = [req.user.id];
    if (status) { query += ' AND status = $2'; params.push(status); }
    query += ' ORDER BY created_at DESC';

    const { rows } = await pool.query(query, params);
    res.json(rows.map(mapTransfer));
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch transfers' });
  }
});

// POST /api/transfers
router.post('/', verifyAuth, async (req, res) => {
  try {
    const { fromWarehouse, toWarehouse, items, notes } = req.body;
    if (!items || !items.length) return res.status(400).json({ error: 'Items are required' });
    if (!fromWarehouse || !toWarehouse) return res.status(400).json({ error: 'Source and destination warehouses are required' });
    if (fromWarehouse === toWarehouse) return res.status(400).json({ error: 'Source and destination cannot be the same' });

    const transferNo = 'TRF-' + Date.now().toString(36).toUpperCase();
    const { rows } = await pool.query(
      'INSERT INTO transfers (transfer_no, from_warehouse, to_warehouse, items, status, notes, created_by, user_id) VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING id',
      [transferNo, fromWarehouse, toWarehouse, JSON.stringify(items), 'Draft', notes || '', req.user.id, req.user.id]
    );

    res.status(201).json({ id: rows[0].id, transferNo, fromWarehouse, toWarehouse, items, status: 'Draft', notes });
  } catch (err) {
    res.status(500).json({ error: 'Failed to create transfer' });
  }
});

// PUT /api/transfers/:id/validate
router.put('/:id/validate', verifyAuth, async (req, res) => {
  try {
    const { rows } = await pool.query('SELECT * FROM transfers WHERE id = $1 AND user_id = $2', [req.params.id, req.user.id]);
    if (rows.length === 0) return res.status(404).json({ error: 'Transfer not found' });
    const transfer = rows[0];
    if (transfer.status === 'Done') return res.status(400).json({ error: 'Transfer already completed' });

    const items = typeof transfer.items === 'string' ? JSON.parse(transfer.items) : (transfer.items || []);

    for (const item of items) {
      const { rows: pRows } = await pool.query('SELECT stock FROM products WHERE id = $1 AND user_id = $2', [item.productId, req.user.id]);
      if (pRows.length > 0) {
        let currentStock = {};
        if (typeof pRows[0].stock === 'string') {
          try { currentStock = JSON.parse(pRows[0].stock); } catch (e) { }
        } else if (pRows[0].stock) {
          currentStock = pRows[0].stock;
        }
        const fromQty = currentStock[transfer.from_warehouse] || 0;
        if (fromQty < Number(item.quantity)) {
          return res.status(400).json({ error: `Insufficient stock for ${item.productName} in source warehouse. Available: ${fromQty}` });
        }
        currentStock[transfer.from_warehouse] = fromQty - Number(item.quantity);
        currentStock[transfer.to_warehouse] = (currentStock[transfer.to_warehouse] || 0) + Number(item.quantity);
        await pool.query('UPDATE products SET stock = $1 WHERE id = $2 AND user_id = $3', [JSON.stringify(currentStock), item.productId, req.user.id]);
      }

      await logStockMovement({
        productId: item.productId, productName: item.productName,
        type: 'transfer', quantity: Number(item.quantity),
        fromLocation: transfer.from_warehouse, toLocation: transfer.to_warehouse,
        referenceDoc: transfer.transfer_no, userId: req.user.id,
      });
    }

    await pool.query('UPDATE transfers SET status = $1, validated_at = NOW() WHERE id = $2 AND user_id = $3', ['Done', req.params.id, req.user.id]);
    res.json({ message: 'Transfer completed', transferNo: transfer.transfer_no });
  } catch (err) {
    console.error('Transfer validate error:', err);
    res.status(500).json({ error: 'Failed to complete transfer' });
  }
});

module.exports = router;

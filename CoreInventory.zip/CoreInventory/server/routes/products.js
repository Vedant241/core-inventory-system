const express = require('express');
const router = express.Router();
const verifyAuth = require('../middleware/auth');
const { pool } = require('../db');

// GET /api/products
router.get('/', verifyAuth, async (req, res) => {
  try {
    const { rows } = await pool.query('SELECT * FROM products WHERE user_id = $1 ORDER BY created_at DESC', [req.user.id]);
    let products = rows.map(p => {
      let parsedStock = {};
      if (typeof p.stock === 'string') {
        try { parsedStock = JSON.parse(p.stock); } catch (e) { }
      } else if (p.stock) {
        parsedStock = p.stock;
      }
      return {
        id: p.id, name: p.name, sku: p.sku, category: p.category,
        unitOfMeasure: p.unit_of_measure,
        stock: parsedStock,
        reorderLevel: p.reorder_level, createdAt: p.created_at,
      };
    });

    const { category, search } = req.query;
    if (category) products = products.filter(p => p.category === category);
    if (search) {
      const s = search.toLowerCase();
      products = products.filter(p => p.name.toLowerCase().includes(s) || (p.sku && p.sku.toLowerCase().includes(s)));
    }
    res.json(products);
  } catch (err) {
    console.error('Products GET error:', err);
    res.status(500).json({ error: 'Failed to fetch products' });
  }
});

// GET /api/products/:id
router.get('/:id', verifyAuth, async (req, res) => {
  try {
    const { rows } = await pool.query('SELECT * FROM products WHERE id = $1 AND user_id = $2', [req.params.id, req.user.id]);
    if (rows.length === 0) return res.status(404).json({ error: 'Product not found' });
    const p = rows[0];
    let parsedStock = {};
    if (typeof p.stock === 'string') {
      try { parsedStock = JSON.parse(p.stock); } catch (e) { }
    } else if (p.stock) {
      parsedStock = p.stock;
    }

    res.json({
      id: p.id, name: p.name, sku: p.sku, category: p.category,
      unitOfMeasure: p.unit_of_measure,
      stock: parsedStock,
      reorderLevel: p.reorder_level, createdAt: p.created_at,
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch product' });
  }
});

// POST /api/products
router.post('/', verifyAuth, async (req, res) => {
  try {
    const { name, sku, category, unitOfMeasure, initialStock, warehouseId, reorderLevel } = req.body;
    if (!name || !sku) return res.status(400).json({ error: 'Name and SKU are required' });

    const { rows: existing } = await pool.query('SELECT id FROM products WHERE sku = $1 AND user_id = $2', [sku, req.user.id]);
    if (existing.length > 0) return res.status(400).json({ error: 'SKU already exists' });

    const stock = {};
    if (initialStock && warehouseId) stock[warehouseId] = Number(initialStock);

    const { rows } = await pool.query(
      'INSERT INTO products (name, sku, category, unit_of_measure, stock, reorder_level, user_id) VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING id',
      [name, sku, category || 'Uncategorized', unitOfMeasure || 'Unit', JSON.stringify(stock), Number(reorderLevel) || 0, req.user.id]
    );

    res.status(201).json({
      id: rows[0].id, name, sku, category: category || 'Uncategorized',
      unitOfMeasure: unitOfMeasure || 'Unit', stock, reorderLevel: Number(reorderLevel) || 0,
    });
  } catch (err) {
    console.error('Products POST error:', err);
    res.status(500).json({ error: 'Failed to create product' });
  }
});

// PUT /api/products/:id
router.put('/:id', verifyAuth, async (req, res) => {
  try {
    const { name, sku, category, unitOfMeasure, reorderLevel } = req.body;
    let updateQuery = 'UPDATE products SET ';
    const values = [];
    let counter = 1;

    if (name) { updateQuery += `name = $${counter++}, `; values.push(name); }
    if (sku) { updateQuery += `sku = $${counter++}, `; values.push(sku); }
    if (category) { updateQuery += `category = $${counter++}, `; values.push(category); }
    if (unitOfMeasure) { updateQuery += `unit_of_measure = $${counter++}, `; values.push(unitOfMeasure); }
    if (reorderLevel !== undefined) { updateQuery += `reorder_level = $${counter++}, `; values.push(Number(reorderLevel)); }

    if (values.length === 0) return res.status(400).json({ error: 'No fields to update' });

    updateQuery = updateQuery.slice(0, -2);
    updateQuery += ` WHERE id = $${counter} AND user_id = $${counter + 1}`;
    values.push(req.params.id, req.user.id);

    await pool.query(updateQuery, values);
    const { rows } = await pool.query('SELECT * FROM products WHERE id = $1 AND user_id = $2', [req.params.id, req.user.id]);
    const p = rows[0];
    let parsedStock = {};
    if (typeof p.stock === 'string') {
      try { parsedStock = JSON.parse(p.stock); } catch (e) { }
    } else if (p.stock) {
      parsedStock = p.stock;
    }

    res.json({
      id: p.id, name: p.name, sku: p.sku, category: p.category,
      unitOfMeasure: p.unit_of_measure,
      stock: parsedStock,
      reorderLevel: p.reorder_level,
    });
  } catch (err) {
    console.error('Products PUT error:', err);
    res.status(500).json({ error: 'Failed to update product' });
  }
});

// DELETE /api/products/:id
router.delete('/:id', verifyAuth, async (req, res) => {
  try {
    await pool.query('DELETE FROM products WHERE id = $1 AND user_id = $2', [req.params.id, req.user.id]);
    res.json({ message: 'Product deleted' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to delete product' });
  }
});

// GET /api/products/categories/list
router.get('/categories/list', verifyAuth, async (req, res) => {
  try {
    const { rows } = await pool.query('SELECT * FROM categories WHERE user_id = $1 ORDER BY name', [req.user.id]);
    res.json(rows.map(c => ({ id: c.id, name: c.name, description: c.description })));
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch categories' });
  }
});

// POST /api/products/categories
router.post('/categories', verifyAuth, async (req, res) => {
  try {
    const { name, description } = req.body;
    if (!name) return res.status(400).json({ error: 'Category name is required' });
    const { rows } = await pool.query(
      'INSERT INTO categories (name, description, user_id) VALUES ($1, $2, $3) RETURNING id',
      [name, description || '', req.user.id]
    );
    res.status(201).json({ id: rows[0].id, name, description: description || '' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to create category' });
  }
});

module.exports = router;

const express = require('express');
const router = express.Router();
const verifyAuth = require('../middleware/auth');
const { pool } = require('../db');

// GET /api/dashboard
router.get('/', verifyAuth, async (req, res) => {
  try {
    const userId = req.user.id;
    const { rows: products } = await pool.query('SELECT id, stock, reorder_level FROM products WHERE user_id = $1', [userId]);
    let lowStockItems = 0, outOfStockItems = 0;
    products.forEach(p => {
      let stockData = {};
      if (typeof p.stock === 'string') {
        try { stockData = JSON.parse(p.stock); } catch (e) { }
      } else if (p.stock) {
        stockData = p.stock;
      }
      const totalStock = Object.values(stockData).reduce((a, b) => a + b, 0);
      if (totalStock === 0) outOfStockItems++;
      else if (p.reorder_level && totalStock <= p.reorder_level) lowStockItems++;
    });

    const { rows: receipts } = await pool.query("SELECT COUNT(*) as count FROM receipts WHERE status = 'Draft' AND user_id = $1", [userId]);
    const { rows: deliveries } = await pool.query("SELECT COUNT(*) as count FROM deliveries WHERE status = 'Draft' AND user_id = $1", [userId]);
    const { rows: transfers } = await pool.query("SELECT COUNT(*) as count FROM transfers WHERE status = 'Draft' AND user_id = $1", [userId]);

    // Recent Activity (last 5 ledger entries for this user)
    const { rows: recentActivity } = await pool.query('SELECT * FROM stock_ledger WHERE user_id = $1 ORDER BY created_at DESC LIMIT 5', [userId]);

    res.json({
      totalProducts: products.length,
      outOfStockItems,
      lowStockItems,
      pendingReceipts: parseInt(receipts[0].count, 10),
      pendingDeliveries: parseInt(deliveries[0].count, 10),
      pendingTransfers: parseInt(transfers[0].count, 10),
      recentActivity: recentActivity.map(a => ({
        id: a.id,
        action: a.type,
        product: a.product_name,
        qty: parseFloat(a.quantity),
        date: a.created_at,
        ref: a.reference_doc
      }))
    });
  } catch (err) {
    console.error('Dashboard error:', err);
    res.status(500).json({ error: 'Failed to fetch dashboard data' });
  }
});

// GET /api/dashboard/stock-ledger — full stock ledger for Move History page
router.get('/stock-ledger', verifyAuth, async (req, res) => {
  try {
    const { rows } = await pool.query('SELECT * FROM stock_ledger WHERE user_id = $1 ORDER BY created_at DESC LIMIT 200', [req.user.id]);
    res.json(rows.map(a => ({
      id: a.id,
      type: a.type,
      productId: a.product_id,
      productName: a.product_name,
      quantity: parseFloat(a.quantity),
      fromLocation: a.from_location,
      toLocation: a.to_location,
      referenceDoc: a.reference_doc,
      timestamp: a.created_at,
    })));
  } catch (err) {
    console.error('Stock ledger error:', err);
    res.status(500).json({ error: 'Failed to fetch stock ledger' });
  }
});

module.exports = router;

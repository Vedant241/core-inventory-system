const express = require('express');
const router = express.Router();
const verifyAuth = require('../middleware/auth');
const { pool } = require('../db');
const { logStockMovement } = require('../utils/stockLedger');

function mapDelivery(d) {
  return {
    id: d.id, deliveryNo: d.delivery_no, customer: d.customer,
    items: typeof d.items === 'string' ? JSON.parse(d.items) : (d.items || []),
    warehouseId: d.warehouse_id, status: d.status, notes: d.notes,
    createdAt: d.created_at, validatedAt: d.validated_at,
  };
}

// GET /api/deliveries
router.get('/', verifyAuth, async (req, res) => {
  try {
    const { status } = req.query;
    let query = 'SELECT * FROM deliveries WHERE user_id = $1';
    const params = [req.user.id];
    if (status) { query += ' AND status = $2'; params.push(status); }
    query += ' ORDER BY created_at DESC';

    const { rows } = await pool.query(query, params);
    res.json(rows.map(mapDelivery));
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch deliveries' });
  }
});

// GET /api/deliveries/:id
router.get('/:id', verifyAuth, async (req, res) => {
  try {
    const { rows } = await pool.query('SELECT * FROM deliveries WHERE id = $1 AND user_id = $2', [req.params.id, req.user.id]);
    if (rows.length === 0) return res.status(404).json({ error: 'Delivery not found' });
    res.json(mapDelivery(rows[0]));
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch delivery' });
  }
});

// POST /api/deliveries
router.post('/', verifyAuth, async (req, res) => {
  try {
    const { customer, items, warehouseId, notes } = req.body;
    if (!items || !items.length) return res.status(400).json({ error: 'Items are required' });

    const deliveryNo = 'DEL-' + Date.now().toString(36).toUpperCase();
    const { rows } = await pool.query(
      'INSERT INTO deliveries (delivery_no, customer, items, warehouse_id, status, notes, created_by, user_id) VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING id',
      [deliveryNo, customer || '', JSON.stringify(items), warehouseId || '', 'Draft', notes || '', req.user.id, req.user.id]
    );

    res.status(201).json({ id: rows[0].id, deliveryNo, customer, items, warehouseId, status: 'Draft', notes });
  } catch (err) {
    res.status(500).json({ error: 'Failed to create delivery' });
  }
});

// PUT /api/deliveries/:id/validate — decrease stock
router.put('/:id/validate', verifyAuth, async (req, res) => {
  try {
    const { rows } = await pool.query('SELECT * FROM deliveries WHERE id = $1 AND user_id = $2', [req.params.id, req.user.id]);
    if (rows.length === 0) return res.status(404).json({ error: 'Delivery not found' });
    const delivery = rows[0];
    if (delivery.status === 'Done') return res.status(400).json({ error: 'Delivery already validated' });

    const items = typeof delivery.items === 'string' ? JSON.parse(delivery.items) : (delivery.items || []);
    const warehouseId = delivery.warehouse_id || 'default';

    for (const item of items) {
      const { rows: pRows } = await pool.query('SELECT stock FROM products WHERE id = $1 AND user_id = $2', [item.productId, req.user.id]);
      if (pRows.length > 0) {
        let currentStock = {};
        if (typeof pRows[0].stock === 'string') {
          try { currentStock = JSON.parse(pRows[0].stock); } catch (e) { }
        } else if (pRows[0].stock) {
          currentStock = pRows[0].stock;
        }
        const currentQty = currentStock[warehouseId] || 0;
        if (currentQty < Number(item.quantity)) {
          return res.status(400).json({ error: `Insufficient stock for ${item.productName}. Available: ${currentQty}` });
        }
        currentStock[warehouseId] = currentQty - Number(item.quantity);
        await pool.query('UPDATE products SET stock = $1 WHERE id = $2 AND user_id = $3', [JSON.stringify(currentStock), item.productId, req.user.id]);
      }

      await logStockMovement({
        productId: item.productId, productName: item.productName,
        type: 'delivery', quantity: -Number(item.quantity),
        fromLocation: warehouseId, referenceDoc: delivery.delivery_no, userId: req.user.id,
      });
    }

    await pool.query('UPDATE deliveries SET status = $1, validated_at = NOW() WHERE id = $2 AND user_id = $3', ['Done', req.params.id, req.user.id]);
    res.json({ message: 'Delivery validated, stock updated', deliveryNo: delivery.delivery_no });
  } catch (err) {
    console.error('Delivery validate error:', err);
    res.status(500).json({ error: 'Failed to validate delivery' });
  }
});

module.exports = router;

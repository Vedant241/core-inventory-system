const express = require('express');
const router = express.Router();
const verifyAuth = require('../middleware/auth');
const { pool } = require('../db');
const { logStockMovement } = require('../utils/stockLedger');

// GET /api/adjustments
router.get('/', verifyAuth, async (req, res) => {
  try {
    const { rows } = await pool.query('SELECT * FROM adjustments WHERE user_id = $1 ORDER BY created_at DESC', [req.user.id]);
    res.json(rows.map(a => ({
      id: a.id, adjustmentNo: a.adjustment_no, productId: a.product_id,
      productName: a.product_name, warehouseId: a.warehouse_id,
      recordedQty: parseFloat(a.recorded_qty) || 0, countedQty: parseFloat(a.counted_qty) || 0,
      difference: parseFloat(a.difference) || 0, reason: a.reason, createdAt: a.created_at,
    })));
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch adjustments' });
  }
});

// POST /api/adjustments
router.post('/', verifyAuth, async (req, res) => {
  try {
    const { productId, productName, warehouseId, countedQty, reason } = req.body;
    if (!productId || countedQty === undefined) return res.status(400).json({ error: 'Product and counted quantity are required' });

    const warehouse = warehouseId || 'default';
    const { rows: pRows } = await pool.query('SELECT * FROM products WHERE id = $1 AND user_id = $2', [productId, req.user.id]);
    if (pRows.length === 0) return res.status(404).json({ error: 'Product not found' });

    const product = pRows[0];
    let currentStock = {};
    if (typeof product.stock === 'string') {
      try { currentStock = JSON.parse(product.stock); } catch (e) { }
    } else if (product.stock) {
      currentStock = product.stock;
    }
    const recordedQty = currentStock[warehouse] || 0;
    const difference = Number(countedQty) - recordedQty;

    currentStock[warehouse] = Number(countedQty);
    await pool.query('UPDATE products SET stock = $1 WHERE id = $2 AND user_id = $3', [JSON.stringify(currentStock), productId, req.user.id]);

    const adjustmentNo = 'ADJ-' + Date.now().toString(36).toUpperCase();
    const { rows } = await pool.query(
      'INSERT INTO adjustments (adjustment_no, product_id, product_name, warehouse_id, recorded_qty, counted_qty, difference, reason, created_by, user_id) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10) RETURNING id',
      [adjustmentNo, productId, productName || product.name, warehouse, recordedQty, Number(countedQty), difference, reason || '', req.user.id, req.user.id]
    );

    await logStockMovement({
      productId, productName: productName || product.name,
      type: 'adjustment', quantity: difference,
      toLocation: warehouse, referenceDoc: adjustmentNo, userId: req.user.id,
    });

    res.status(201).json({
      id: rows[0].id, adjustmentNo, productId,
      productName: productName || product.name, warehouseId: warehouse,
      recordedQty, countedQty: Number(countedQty), difference, reason,
    });
  } catch (err) {
    console.error('Adjustment error:', err);
    res.status(500).json({ error: 'Failed to create adjustment' });
  }
});

module.exports = router;

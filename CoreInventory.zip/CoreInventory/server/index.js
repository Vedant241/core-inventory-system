require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'public')));

// API Routes
app.use('/api/auth', require('./routes/auth'));
app.use('/api/dashboard', require('./routes/dashboard'));
app.use('/api/products', require('./routes/products'));
app.use('/api/receipts', require('./routes/receipts'));
app.use('/api/deliveries', require('./routes/deliveries'));
app.use('/api/transfers', require('./routes/transfers'));
app.use('/api/adjustments', require('./routes/adjustments'));
app.use('/api/warehouses', require('./routes/warehouses'));

// SPA fallback
app.get('*', (req, res) => {
  if (!req.path.startsWith('/api')) {
    const requestedFile = path.join(__dirname, '..', 'public', req.path);
    res.sendFile(requestedFile, (err) => {
      if (err) {
        res.sendFile(path.join(__dirname, '..', 'public', 'index.html'));
      }
    });
  }
});

app.listen(PORT, () => {
  console.log(`✅ CoreInventory server running on http://localhost:${PORT}`);
});

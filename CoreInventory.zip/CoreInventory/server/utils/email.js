const nodemailer = require('nodemailer');

// Create reusable transporter using Gmail SMTP
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.SMTP_EMAIL,
    pass: process.env.SMTP_PASSWORD,
  },
});

function isSmtpConfigured() {
  const email = process.env.SMTP_EMAIL || '';
  const pass = process.env.SMTP_PASSWORD || '';
  return email && pass && !email.includes('your_') && !pass.includes('your_');
}

/**
 * Send OTP email for password reset
 */
async function sendOTPEmail(toEmail, otp) {
  const html = buildOTPTemplate({
    title: 'Password Reset Request',
    message: 'You requested a password reset for your CoreInventory account. Use the OTP code below to verify your identity:',
    otp,
  });

  await transporter.sendMail({
    from: `"CoreInventory" <${process.env.SMTP_EMAIL}>`,
    to: toEmail,
    subject: `🔐 Your CoreInventory Password Reset OTP: ${otp}`,
    html,
  });
}

/**
 * Send OTP email for signup verification
 */
async function sendSignupOTPEmail(toEmail, otp) {
  const html = buildOTPTemplate({
    title: 'Verify Your Email',
    message: 'Welcome to CoreInventory! Please verify your email address by entering the OTP code below to complete your registration:',
    otp,
  });

  await transporter.sendMail({
    from: `"CoreInventory" <${process.env.SMTP_EMAIL}>`,
    to: toEmail,
    subject: `✅ Verify your CoreInventory account: ${otp}`,
    html,
  });
}

/**
 * Reusable OTP email template
 */
function buildOTPTemplate({ title, message, otp }) {
  return `
<!DOCTYPE html>
<html>
<head><meta charset="utf-8"></head>
<body style="margin:0;padding:0;background:#0f172a;font-family:'Segoe UI',Tahoma,Geneva,Verdana,sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#0f172a;padding:40px 0;">
    <tr><td align="center">
      <table width="480" cellpadding="0" cellspacing="0" style="background:#1e293b;border-radius:16px;overflow:hidden;box-shadow:0 20px 60px rgba(0,0,0,0.3);">
        
        <tr><td style="background:linear-gradient(135deg,#10b981,#059669);padding:32px;text-align:center;">
          <h1 style="margin:0;color:#fff;font-size:28px;font-weight:700;letter-spacing:-0.5px;">CoreInventory</h1>
          <p style="margin:6px 0 0;color:rgba(255,255,255,0.8);font-size:14px;">${title}</p>
        </td></tr>
        
        <tr><td style="padding:40px 32px;">
          <p style="margin:0 0 20px;color:#e2e8f0;font-size:16px;line-height:1.6;">${message}</p>
          
          <div style="background:#0f172a;border:2px solid #10b981;border-radius:12px;padding:24px;text-align:center;margin:24px 0;">
            <p style="margin:0 0 8px;color:#94a3b8;font-size:12px;text-transform:uppercase;letter-spacing:2px;">Your OTP Code</p>
            <p style="margin:0;color:#10b981;font-size:40px;font-weight:800;letter-spacing:12px;">${otp}</p>
          </div>
          
          <p style="margin:20px 0 0;color:#94a3b8;font-size:14px;line-height:1.6;">
            ⏱️ This code expires in <strong style="color:#f59e0b;">10 minutes</strong>.<br>
            🔒 If you didn't request this, you can safely ignore this email.
          </p>
        </td></tr>
        
        <tr><td style="padding:20px 32px;border-top:1px solid #334155;text-align:center;">
          <p style="margin:0;color:#64748b;font-size:12px;">
            © ${new Date().getFullYear()} CoreInventory — Inventory Management System
          </p>
        </td></tr>
        
      </table>
    </td></tr>
  </table>
</body>
</html>`;
}

module.exports = { sendOTPEmail, sendSignupOTPEmail, isSmtpConfigured };

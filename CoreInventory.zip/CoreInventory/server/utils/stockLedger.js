const { pool } = require('../db');

/**
 * Logs a movement of stock into the stock_ledger table
 */
async function logStockMovement({ productId, productName, type, quantity, fromLocation, toLocation, referenceDoc, userId }) {
  try {
    await pool.query(
      `INSERT INTO stock_ledger 
      (product_id, product_name, type, quantity, from_location, to_location, reference_doc, user_id) 
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`,
      [
        productId || null,
        productName || '',
        type,
        parseFloat(quantity) || 0,
        fromLocation || null,
        toLocation || null,
        referenceDoc || null,
        userId || null
      ]
    );
  } catch (err) {
    console.error('Failed to log stock movement:', err);
  }
}

module.exports = { logStockMovement };
